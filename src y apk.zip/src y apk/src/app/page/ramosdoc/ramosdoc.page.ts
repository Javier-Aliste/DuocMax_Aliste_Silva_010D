import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ramosdoc',
  templateUrl: './ramosdoc.page.html',
  styleUrls: ['./ramosdoc.page.scss'],
})
export class RamosdocPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
