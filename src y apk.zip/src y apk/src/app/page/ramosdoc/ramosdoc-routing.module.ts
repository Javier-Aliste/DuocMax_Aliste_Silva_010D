import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { RamosdocPage } from './ramosdoc.page';

const routes: Routes = [
  {
    path: '',
    component: RamosdocPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class RamosdocPageRoutingModule {}
