import { Component, OnInit } from '@angular/core';
import { ApirestService } from '../../service/apirest.service';
import { NavController } from '@ionic/angular';
import { Article } from '../../interfaces/interfaces';
import { MenuController } from '@ionic/angular';

@Component({
  selector: 'app-apii',
  templateUrl: './apii.page.html',
  styleUrls: ['./apii.page.scss'],
})
export class ApiiPage implements OnInit {

  api: Article[] = [];

  constructor(private menuController:MenuController,
              private navController:NavController,
              private ApirestService:ApirestService,
    ) { }

  ngOnInit() {
    this.ApirestService.getTopHeadLines().subscribe(resp =>{
      console.log('api',resp)
      this.api.push(...resp.articles)
    })
  }

  mostrarMenu()
  {
    this.menuController.open('first');
  }

  async salir(){
    if(localStorage.getItem('ingresando') || localStorage.getItem('ingresado') ){
      localStorage.removeItem('ingresando');
      localStorage.removeItem('ingresado');
      console.log('pase por aqui');
      this.navController.navigateRoot('ingresarcomo');
    
    }
    
    }
}
