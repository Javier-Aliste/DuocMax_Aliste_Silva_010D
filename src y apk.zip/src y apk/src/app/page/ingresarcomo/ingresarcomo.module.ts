import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { IngresarcomoPageRoutingModule } from './ingresarcomo-routing.module';

import { IngresarcomoPage } from './ingresarcomo.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    IngresarcomoPageRoutingModule
  ],
  declarations: [IngresarcomoPage]
})
export class IngresarcomoPageModule {}
