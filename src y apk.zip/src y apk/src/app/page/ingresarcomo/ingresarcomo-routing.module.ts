import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { IngresarcomoPage } from './ingresarcomo.page';

const routes: Routes = [
  {
    path: '',
    component: IngresarcomoPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class IngresarcomoPageRoutingModule {}
