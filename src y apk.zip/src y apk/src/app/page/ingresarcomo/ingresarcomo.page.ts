import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ingresarcomo',
  templateUrl: './ingresarcomo.page.html',
  styleUrls: ['./ingresarcomo.page.scss'],
})
export class IngresarcomoPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
