import { Component, OnInit } from '@angular/core';
import { MenuController } from '@ionic/angular';
import { NavController } from '@ionic/angular';
@Component({
  selector: 'app-informacion2',
  templateUrl: './informacion2.page.html',
  styleUrls: ['./informacion2.page.scss'],
})
export class Informacion2Page implements OnInit {

  constructor(private menuController: MenuController,
    private navController:NavController) { }

  ngOnInit() {
  }
  mostrarMenu(){
    this.menuController.open('first');
  }

  async salir(){
    if(localStorage.getItem('ingresado')){
      localStorage.removeItem('ingresado');
      console.log('pase por aqui');
      this.navController.navigateRoot("ingresarcomo");
    }
  }
}
