import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { Informacion2PageRoutingModule } from './informacion2-routing.module';

import { Informacion2Page } from './informacion2.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    Informacion2PageRoutingModule
  ],
  declarations: [Informacion2Page]
})
export class Informacion2PageModule {}
