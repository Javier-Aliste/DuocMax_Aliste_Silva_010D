import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ramos',
  templateUrl: './ramos.page.html',
  styleUrls: ['./ramos.page.scss'],
})
export class RamosPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
