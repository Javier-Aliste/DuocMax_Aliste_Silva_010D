import { Component, OnInit } from '@angular/core';
import { RegistroDocenteService,Docente } from '../../service/registro-docente.service';
import { AlertController } from '@ionic/angular';
import { NavController } from '@ionic/angular';
import { FormGroup, FormControl, Validators, FormBuilder} from '@angular/forms';

@Component({
  selector: 'app-login2',
  templateUrl: './login2.page.html',
  styleUrls: ['./login2.page.scss'],
})
export class Login2Page implements OnInit {

  formularioLogin: FormGroup;
  docente : Docente[] = [];

  constructor(private alertController: AlertController,
              private navController: NavController,
              private registroDocente: RegistroDocenteService,
              private fb: FormBuilder) { 
                this.formularioLogin = this.fb.group({
                  'correo' : new FormControl("", Validators.required),
                  'password' : new FormControl ("", Validators.required)
                })
              }

  ngOnInit() {
  }
  async Ingresar(){
    var f = this.formularioLogin.value;
    var a=0;
    this.registroDocente.getUsuarios().then(datos=>{ 
      this.docente = datos; 
      if (!datos || datos.length==0){
        return null;
      }
      for (let obj of this.docente){
        if (f.correo == obj.correoUsuario && f.password==obj.passUsuario){
          a=1;
          console.log('ingresado');
          localStorage.setItem('ingresado','true');
          this.navController.navigateRoot('ramosdoc');
        }
      }//findelfor
      if(a==0){
        this.alertMsg();
      }
    })
  }//findelmetodo

  async alertMsg(){
    const alert = await this.alertController.create({
      header: 'Error...',
      message: 'Los datos ingresados son incorrectos,vuelve a intentar',
      buttons: ['Aceptar']
    })
    await alert.present();
    return;
  } 
}
