import { Component, OnInit } from '@angular/core';
import { RegistroDocenteService, Docente } from '../../service/registro-docente.service';
import { AlertController } from '@ionic/angular';
import { ToastController } from '@ionic/angular';
import { NavController } from '@ionic/angular';
import {
  FormGroup, FormControl, Validators, FormBuilder
} from '@angular/forms';

@Component({
  selector: 'app-registro2',
  templateUrl: './registro2.page.html',
  styleUrls: ['./registro2.page.scss'],
})
export class Registro2Page implements OnInit {
  formularioRegistro: FormGroup; 
  newDocente: Docente = <Docente>{};
  usuarios: Docente[] =[];
  constructor(private alertController: AlertController,
              private registroDocente:RegistroDocenteService,
              private toast: ToastController,
              private navController : NavController,
              private fb:FormBuilder) { 
                this.formularioRegistro = this.fb.group({
                  'nombre' : new FormControl("", Validators.required), 
                  'correo' : new FormControl("", [Validators.required,Validators.email]), 
                  'password': new FormControl("", Validators.compose([
                    Validators.required,
                    Validators.minLength(8),
                    Validators.maxLength(12), 

                  ])), 
                  'confirmaPass': new FormControl("", Validators.compose([
                    Validators.required,
                    Validators.minLength(8),
                    Validators.maxLength(12),

                  ])),
                });                
              }

  ngOnInit() {
  }

  async CrearUsuario(){
    var form = this.formularioRegistro.value;
    var existe = 0;

    if(this.formularioRegistro.invalid){
      this.alertError();
    }
    else{
      this.newDocente.nomUsuario = form.nombre;
      this.newDocente.correoUsuario  = form.correo;
      this.newDocente.passUsuario = form.password;
      this.newDocente.repassUsuario = form.confirmaPass;

      this.registroDocente.getUsuarios().then(datos=> {
      this.usuarios = datos;
      
      if(!datos || datos.length==0){
        this.registroDocente.addUsuario(this.newDocente).then(dato=>{
          this.newDocente = <Docente>{};
          this.showToast('Docente Creado ');
        });
        this.formularioRegistro.reset();
        this.navController.navigateRoot('login2');

      } else{

        for (let obj of this.usuarios){
          if (this.newDocente.correoUsuario == obj.correoUsuario){
            existe =1;
          }
        }

        if(existe == 1){
          this.alertCorreoDuplicado();
          this.formularioRegistro.reset();
        }
        else{
          this.registroDocente.addUsuario(this.newDocente).then(dato=>{
            this.newDocente=<Docente>{};
            this.showToast('Estudiante Creado ');
          });
          this.formularioRegistro.reset();
          this.navController.navigateRoot('login');
        }
      }
      })
    }


  }//findelmetodo

  async alertError(){
    const alert = await this.alertController.create({ 
      header: 'Error..',
      message: 'Debe completar todos los datos',
      buttons: ['Aceptar']
    })
    await alert.present();
  }

  async showToast(msg){
    const toast = await this.toast.create({
      message: msg,
      duration: 2000
    })
    await toast.present();
  }
  async alertCorreoDuplicado(){
    const alert = await this.alertController.create({
      header: 'Error...',
      message: 'El correo ingresado ya existe',
      buttons: ['ok']
    })
    await alert.present();

  }
}
