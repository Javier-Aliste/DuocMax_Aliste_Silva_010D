import { Component, OnInit } from '@angular/core';
import { AlertController } from '@ionic/angular';
import { RegistroEstudianteService, Estudiantes } from '../../service/registro-estudiante.service';

interface Componente{
  icon:string;
  name:string;
  redirecTo:string;
}

@Component({
  selector: 'app-menu',
  templateUrl: './menu.page.html',
  styleUrls: ['./menu.page.scss'],
})
export class MenuPage implements OnInit {

  newEstudiantes: Estudiantes = <Estudiantes>{};
  
  constructor(private alertController:AlertController,
    private RegistroEstudianteService:RegistroEstudianteService) { }

  ngOnInit() {
  }

  async bienvenido(){
    const alert = await this.alertController.create({
      header: 'Saludo Estudiante :D',
      subHeader: 'Bienvenido',
      message: 'Gracias por visitar nuestra app ',
      buttons: ['OK'],
    });
    await alert.present();
  }

  
  componentes: Componente[] = [ 
    {
      icon: 'home-outline',
      name: 'Inicio',
      redirecTo: '/menu/inicio',
    },
    {
      icon: 'book-outline',
      name: 'Lista',
      redirecTo: '/menu/perfil',
    },

    {
      icon: 'pencil-outline',
      name: 'api',
      redirecTo: '/menu/apii',
    },

    {
      icon: 'information-outline',
      name: 'infomacion de la asignatura',
      redirecTo: '/menu/informacion',
    },
  ];


}
