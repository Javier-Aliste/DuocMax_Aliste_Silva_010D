import { Component, OnInit } from '@angular/core';
import { AlertController } from '@ionic/angular';

interface Componente{
  icon:string;
  name:string;
  redirecTo:string;
}
@Component({
  selector: 'app-menu2',
  templateUrl: './menu2.page.html',
  styleUrls: ['./menu2.page.scss'],
})
export class Menu2Page implements OnInit {

  constructor(private alertController:AlertController,) { }

  ngOnInit() {
  }

  async bienvenido(){
    const alert = await this.alertController.create({
      header: 'Saludos Docente',
      subHeader: 'Bienvenido',
      message: 'Gracias por visitar nuestra app ',
      buttons: ['OK'],
    });
    await alert.present();
  }

  componentes: Componente[] = [
    {
      icon: 'home-outline',
      name: 'Inicio',
      redirecTo: '/menu2/inicio2',
    },
    {
      icon: 'book-outline',
      name: 'Lista',
      redirecTo: '/menu2/perfil',
    },
    {
      icon: 'pencil-outline',
      name: 'api',
      redirecTo: '/menu2/apii',
    },
    {
      
      icon: 'information-outline',
      name: 'infomacion de la asignatura',
      redirecTo: '/menu2/informacion2',
    },
  ]
}
