import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { Menu2Page } from './menu2.page';

const routes: Routes = [
  {
    path: '',
    component: Menu2Page,
    children: [
      {
        path: 'informacion2',
        loadChildren: () => import('../informacion2/informacion2.module').then( m => m.Informacion2PageModule)
      },
      {
        path: 'perfil',
        loadChildren: () => import('../perfil/perfil.module').then( m => m.PerfilPageModule)
      },
      {
        path: 'inicio2',
        loadChildren: () => import('../inicio2/inicio2.module').then( m => m.Inicio2PageModule)
      },
      {
        path: 'apii',
        loadChildren: () => import('../apii/apii.module').then( m => m.ApiiPageModule)
      },
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class Menu2PageRoutingModule {}
