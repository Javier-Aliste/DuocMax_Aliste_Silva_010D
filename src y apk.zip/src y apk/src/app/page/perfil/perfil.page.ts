import { Component, OnInit, ViewChild } from '@angular/core';
import { MenuController } from '@ionic/angular';
import { RegistroEstudianteService, Estudiantes } from '../../service/registro-estudiante.service';
import { Platform, ToastController, IonList } from '@ionic/angular';
import { NavController } from '@ionic/angular';
@Component({
  selector: 'app-perfil',
  templateUrl: './perfil.page.html',
  styleUrls: ['./perfil.page.scss'],
})
export class PerfilPage implements OnInit {

  estudiantes : Estudiantes[] = [];
  
  constructor(private menuController: MenuController,
              private registroEstudiantes: RegistroEstudianteService,
              private plt: Platform,
              private navController:NavController) { 
                this.plt.ready().then(()=>{
                  this.loadEstudiantes();
                })
              }

  ngOnInit() {
  }

  mostrarMenu(){
    this.menuController.open('first');
  }

loadEstudiantes(){
  this.registroEstudiantes.getUsuarios().then(estudiantes=>{
    this.estudiantes = estudiantes;
  })
}
async salir(){
  if(localStorage.getItem('ingresado')){
    localStorage.removeItem('ingresado');
    console.log('pase por aqui');
    this.navController.navigateRoot("ingresarcomo");
  }
}

}
