import { Component, OnInit } from '@angular/core';
import { RegistroEstudianteService,Estudiantes } from '../../service/registro-estudiante.service';
import { AlertController } from '@ionic/angular';
import { NavController } from '@ionic/angular';
import { FormGroup, FormControl, Validators, FormBuilder} from '@angular/forms';

@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage implements OnInit {

  formularioLogin: FormGroup;
  estudiante : Estudiantes[] = [];

  constructor(private alertController: AlertController,
              private navController: NavController,
              private registroEstudiante:RegistroEstudianteService,
              private fb: FormBuilder) { 
                this.formularioLogin = this.fb.group({
                  'correo' : new FormControl("", Validators.required),
                  'password' : new FormControl ("", Validators.required)
                })
              }

  ngOnInit() {
  }

  async Ingresar(){
    var f = this.formularioLogin.value;
    var a=0;
    this.registroEstudiante.getUsuarios().then(datos=>{ 
      this.estudiante = datos; 
      if (!datos || datos.length==0){
        return null;
      }
      for (let obj of this.estudiante){
        if (f.correo == obj.correoUsuario && f.password==obj.passUsuario){
          a=1;
          console.log('ingresado');
          localStorage.setItem('ingresado','true');
          this.navController.navigateRoot('ramos');
        }
      }//findelfor
      if(a==0){
        this.alertMsg();
      }
    })
  }//findelmetodo

  async alertMsg(){
    const alert = await this.alertController.create({
      header: 'Error...',
      message: 'Los datos ingresados son incorrectos,vuelve a intentar',
      buttons: ['Aceptar']
    })
    await alert.present();
    return;
  }
}
