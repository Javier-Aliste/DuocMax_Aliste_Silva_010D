import { Injectable } from '@angular/core';
import { Storage } from '@ionic/storage';

export interface Docente{
  nomUsuario: string;
  correoUsuario:string;
  passUsuario:string;
  repassUsuario: string; 
}
const USERS_KEY = 'my-docente';  

@Injectable({
  providedIn: 'root'
})
export class RegistroDocenteService {

  private _storage: Storage;

  constructor(private storage:Storage) {
  this.init();
  }

    //creamos el storage de Usuarios
    async init(){
      const storage = await this.storage.create();
      this._storage = storage;
    }

    //creamos un Usuario
    async addUsuario(dato: Docente):Promise<any>{
      return this.storage.get(USERS_KEY).then((datos: Docente[])=>{ 
        if(datos){
          datos.push(dato);    //agregamos un objeto al storage
          return this.storage.set(USERS_KEY,datos);
        }
        else{
          return this.storage.set(USERS_KEY, [dato]);
        }
      })
     }//findelmetodo

  //obtener todos los objetos desde el storage 
  async getUsuarios():Promise<Docente[]>{
    return this.storage.get(USERS_KEY);
  }     
}
