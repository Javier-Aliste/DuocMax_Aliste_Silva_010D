import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';

const routes: Routes = [

  {
    path: '',
    redirectTo: 'ingresarcomo',
    pathMatch: 'full'
  },
  {
    path: 'login',
    loadChildren: () => import('./page/login/login.module').then( m => m.LoginPageModule)
  },
  {
    path: 'registro',
    loadChildren: () => import('./page/registro/registro.module').then( m => m.RegistroPageModule)
  },
  {
    path: 'ramos',
    loadChildren: () => import('./page/ramos/ramos.module').then( m => m.RamosPageModule)
  },
  
  {
    path: 'menu',
    loadChildren: () => import('./page/menu/menu.module').then( m => m.MenuPageModule)
  },
  {
    path: 'ingresarcomo',
    loadChildren: () => import('./page/ingresarcomo/ingresarcomo.module').then( m => m.IngresarcomoPageModule)
  },
  {
    path: 'login2',
    loadChildren: () => import('./page/login2/login2.module').then( m => m.Login2PageModule)
  },
  {
    path: 'menu2',
    loadChildren: () => import('./page/menu2/menu2.module').then( m => m.Menu2PageModule)
  },
  {
    path: 'registro2',
    loadChildren: () => import('./page/registro2/registro2.module').then( m => m.Registro2PageModule)
  },
  {
    path: 'ramosdoc',
    loadChildren: () => import('./page/ramosdoc/ramosdoc.module').then( m => m.RamosdocPageModule)
  },



];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
